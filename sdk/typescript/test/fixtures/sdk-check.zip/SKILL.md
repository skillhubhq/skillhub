---
name: sdk-check
description: Verify Go and TypeScript RPC interoperability.
---
Fixture instructions only.
